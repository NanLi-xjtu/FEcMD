Tests for the following classes: Configuration, Neighborhood

The files are:
VASP/                 VASP POSCAR and OUTCAR files
errorneous/           configurations reading wrich should raise errors
identical/            identical databases
binary_sample.cfg     a single configuration in a binary format
period_ext_test.cfg   configurations for the periodic extension test
reading_test.cfg      a small number of configurations, mainly to test reading
