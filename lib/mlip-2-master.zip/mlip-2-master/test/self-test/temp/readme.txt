Folder for temporary files produced by unit test (self-test)
