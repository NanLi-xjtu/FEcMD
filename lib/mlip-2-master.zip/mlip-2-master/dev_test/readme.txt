temp/ - a folder where temporary data is created
configurations/ - a folder with input files for testing Configuration, Neighborhood