#include "pair_MLIP.h"

int ntypes;

PairMLIP::PairMLIP()
{
}
PairMLIP::~PairMLIP()
{
	MLIP_finalize();
}
void PairMLIP::compute(int eflag, int vflag)
{
	if (mode == 0) { // nbh version
		double energy = 0;
		double *p_site_en = NULL;
		double **p_site_virial = NULL;
//    if (eflag_atom) p_site_en = &eatom[0];
//    if (vflag_atom) p_site_virial = vatom;
/*
		MLIP_calc_nbh(list->inum, 
			list->ilist, 
			list->numneigh, 
			list->firstneigh,
			atom->nlocal,
			atom->nghost,
			atom->x, 
			atom->type,
			atom->f, 
			energy,
			p_site_en,      // if NULL no site energy is calculated
			p_site_virial); // if NULL no virial stress per atom is calculated
*/
//    if (eflag_global) eng_vdwl += energy;
//    if (vflag_fdotr) virial_fdotr_compute();
	} else { //cfg version
	}
}
void PairMLIP::allocate()
{
}
void PairMLIP::settings()
{
	sprintf (MLIPsettings_filename, "in/mlip.ini");
	sprintf (MLIPlog_filename, "out/mlip.log");
}
void PairMLIP::coeff(int narg, char **arg)
{
}
void PairMLIP::init_style()
{
	printf ("\ninit ...\n");
	MLIP_init(MLIPsettings_filename, MLIPlog_filename, ntypes, cutoff, mode);
	printf ("ntypes = %d, cutoff = %.3f A, mode = %d\n", ntypes, cutoff, mode);
}

int main ()
{
	PairMLIP mlp;
	
	ntypes = 1;

	mlp.settings ();
	mlp.init_style ();
}
