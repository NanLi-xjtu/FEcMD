There are the files for developing under Windows.
Provided for convenience. Will not be maintained properly.
