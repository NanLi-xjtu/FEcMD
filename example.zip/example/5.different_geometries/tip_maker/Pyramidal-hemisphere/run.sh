../../../fecmd PH
