../../../../fecmd PS
