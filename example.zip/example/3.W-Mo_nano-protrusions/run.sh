../../fecmd Maxwell
